console.log(`
Implemented Java Native library
its Open Source You can edit anything you like 
and use it for commercial purposes .

          opensource license 
`)
function Toast(text){
NativeJava.showToast(text)
}
function InstallText(text,createfileName) {
    NativeJava.DownloadText(text, createfileName);
}
function SetOrientation( portrait, portrait_reversed, landscape, landscape_reversed ){
NativeJava.Orientation( portrait, portrait_reversed , landscape, landscape_reversed )
}
