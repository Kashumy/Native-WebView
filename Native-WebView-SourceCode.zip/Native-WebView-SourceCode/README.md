# Native-WebView
this my java/xml project called NativeWebView its fullscreen and it uses js that can communicate with java code Its my the best template for making html games ;) maded in 2 days
